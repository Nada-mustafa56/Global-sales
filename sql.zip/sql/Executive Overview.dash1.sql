--Dashboard 1: Executive Overview

-- Total Revenue (KPI)
SELECT
    ROUND(SUM(Sales),2) AS Total_Sales
    FROM Fact_Sales;
-- Total Profit (KPI)
SELECT
    ROUND(SUM(Profit),2) AS Total_Profit 
    FROM Fact_Sales;
-- Total Orders (KPI)
SELECT
    COUNT(DISTINCT Order_ID) AS Total_Orders
    FROM Fact_Sales;
--Average Sale (KPI)
SELECT
    ROUND(AVG(Sales),2) AS Average_Sale
FROM Fact_Sales;
--Which market generates the highest sales?
SELECT
    l.Market,
    ROUND(SUM(f.Sales),2) AS Total_Sales
FROM Fact_Sales f
JOIN Dim_Location l
ON f.LocationKey = l.LocationKey
GROUP BY l.Market
ORDER BY Total_Sales DESC;
--Does increasing discounts reduce profit?
SELECT
    ROUND(Discount,2) AS Discount,
    ROUND(SUM(Sales),2) AS Total_Sales,
    ROUND(SUM(Profit),2) AS Total_Profit
FROM Fact_Sales
GROUP BY Discount
ORDER BY Discount;
--What is the average shipping cost by region?
SELECT
    l.Region,
    ROUND(AVG(f.Shipping_Cost),2) AS Average_Shipping_Cost
FROM Fact_Sales f
JOIN Dim_Location l
ON f.LocationKey = l.LocationKey
GROUP BY l.Region
ORDER BY Average_Shipping_Cost DESC;
--Which customer segment brings the highest revenue?
SELECT
    c.Segment,
    ROUND(SUM(f.Sales),2) AS Total_Revenue,
    ROUND(SUM(f.Profit),2) AS Total_Profit
FROM Fact_Sales f
JOIN Dim_Customer c
ON f.Customer_ID = c.Customer_ID
GROUP BY c.Segment
ORDER BY Total_Revenue DESC;
-- What is the yearly sales trend?
SELECT
    d.Order_Year,
    ROUND(SUM(f.Sales),2) AS Total_Sales
FROM Fact_Sales f
JOIN Dim_Date d
ON f.DateKey = d.DateKey
GROUP BY d.Order_Year
ORDER BY d.Order_Year;



-- Key Business Insights

/*
The Executive Overview dashboard reveals several important findings:
 Total sales reached $13.85 million, while total profit amounted to $1.61 million across 25,035 orders.
 The average sales amount was $247.39 per transaction record.
 APAC generated the highest total sales, making it the company's best-performing market.
 Higher discount levels generally reduce profitability, indicating that excessive discounting impacts profit margins.
 North Asia recorded the highest average shipping cost among all regions.
 The Consumer segment contributed the largest share of total revenue.
 Sales followed a positive yearly trend, with 2011 achieving the highest sales performance.
*/