--Dashboard 2 : Product Performance

--KPI 1: Total Products (KPI)
SELECT
    COUNT(DISTINCT Product_ID) AS Total_Products
FROM Dim_Product;
--KPI 2: Total Categories (KPI)
SELECT
    COUNT(DISTINCT Category) AS Total_Categories
FROM Dim_Product;
--KPI 3: Total Sales (KPI)
SELECT
    ROUND(SUM(Sales),2) AS Total_Sales
FROM Fact_Sales;
--KPI 4: Total Quantity Sold (KPI)
SELECT
    SUM(Quantity) AS Total_Quantity
FROM Fact_Sales;
--Average Sales by Category
SELECT
    p.Category,
    ROUND(AVG(f.Sales),2) AS Average_Sales
FROM Fact_Sales f
JOIN Dim_Product p
ON f.Product_ID=p.Product_ID
GROUP BY p.Category
ORDER BY Average_Sales DESC;
--What are the Top 10 products by sales?
SELECT TOP 10
    p.Product_Name,
    ROUND(SUM(f.Sales),2) AS Total_Sales
FROM Fact_Sales f
JOIN Dim_Product p
ON f.Product_ID = p.Product_ID
GROUP BY p.Product_Name
ORDER BY Total_Sales DESC;
--Product Category Performance
SELECT
    p.Category,
    ROUND(SUM(f.Sales),2) AS Total_Sales,
    SUM(f.Quantity) AS Total_Quantity,
    ROUND(SUM(f.Profit),2) AS Total_Profit
FROM Fact_Sales f
JOIN Dim_Product p
ON f.Product_ID=p.Product_ID
GROUP BY p.Category
ORDER BY Total_Sales DESC;
--Average Profit by Category
SELECT
    p.Category,
    ROUND(AVG(f.Profit),2) AS Average_Profit
FROM Fact_Sales f
JOIN Dim_Product p
ON f.Product_ID=p.Product_ID
GROUP BY p.Category
ORDER BY Average_Profit DESC;
 

--- Key Business Insights

/*
 The Product Performance dashboard provides valuable insights into product sales and category performance.
 The company offers 10292 products across 3 product categories.
 Total sales reached $13.85 million, with a total quantity sold of 196072 units.
 Technology recorded the highest average sales among all product categories.
 Apple Smart Phone, Full Size was the best-selling product in terms of total sales.
 Technology achieved the strongest overall performance, generating the highest sales, quantity sold, and profit.
 Technology recorded the highest average profit, indicating stronger profitability compared to the other categories.
 Product analysis shows that category performance varies in both sales volume and profitability, helping identify the company's highest-performing product lines.
*/