--Dashboard 3: Customer & Geographic Analysis

--Total Customers(KPI)
SELECT
    COUNT(DISTINCT Customer_ID) AS Total_Customers
FROM Dim_Customer ;
--Total Countries(KPI)
SELECT
    COUNT(DISTINCT Country) AS Total_Countries
FROM Dim_Location;
--Total Cities(KPI)
SELECT
    COUNT(DISTINCT City) AS Total_Cities
FROM Dim_Location;
--Total Regions(KPI)
SELECT
    COUNT(DISTINCT Region) AS Total_Regions
FROM Dim_Location;
--Revenue by Customer Segment
SELECT
    c.Segment,
    ROUND(SUM(f.Sales),2) AS Total_Revenue
FROM Fact_Sales f
JOIN Dim_Customer c
ON f.Customer_ID = c.Customer_ID
GROUP BY c.Segment
ORDER BY Total_Revenue DESC;
--Top 10 Customers by Profit
SELECT TOP 10
    c.Customer_Name,
    ROUND(SUM(f.Profit),2) AS Total_Profit
FROM Fact_Sales f
JOIN Dim_Customer c
ON f.Customer_ID = c.Customer_ID
GROUP BY c.Customer_Name
ORDER BY Total_Profit DESC;
--Sales by Country
SELECT
    l.Country,
    ROUND(SUM(f.Sales),2) AS Total_Sales
FROM Fact_Sales f
JOIN Dim_Location l
ON f.LocationKey = l.LocationKey
GROUP BY l.Country
ORDER BY Total_Sales DESC;
--Sales by Region
SELECT
    l.Region,
    ROUND(SUM(f.Sales),2) AS Total_Sales,
    ROUND(SUM(f.Profit),2) AS Total_Profit
FROM Fact_Sales f
JOIN Dim_Location l
ON f.LocationKey = l.LocationKey
GROUP BY l.Region
ORDER BY Total_Sales DESC;
--Top 10 Cities by Orders
SELECT TOP 10
    l.City,
    COUNT(DISTINCT f.Order_ID) AS Total_Orders
FROM Fact_Sales f
JOIN Dim_Location l
ON f.LocationKey = l.LocationKey
GROUP BY l.City
ORDER BY Total_Orders DESC;
--Customer Performance Table
SELECT TOP 10
    c.Customer_Name,
    ROUND(SUM(f.Sales),2) AS Total_Sales,
    ROUND(SUM(f.Profit),2) AS Total_Profit,
    SUM(f.Quantity) AS Total_Quantity
FROM Fact_Sales f
JOIN Dim_Customer c
ON f.Customer_ID = c.Customer_ID
GROUP BY c.Customer_Name
ORDER BY Total_Sales DESC;

--- Key Business Insights

/*
The company serves customers across 147 countries, 13 regions, and 3636 cities.
The Consumer segment generates the highest total revenue.
Raymond Buch is the most profitable customer based on total profit.
United States contributes the highest total sales among all countries.
The Central region achieves the strongest sales performance.
 A small number of customers account for a significant share of total revenue, highlighting the importance of customer retention.
*/